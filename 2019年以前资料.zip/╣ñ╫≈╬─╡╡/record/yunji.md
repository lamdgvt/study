
云集统一门户  http://sso.yunjiglobal.com/#/
阿里测试  http://tsso.yunjiglobal.com/index
腾讯测试  http://txsso.yunjiglobal.com/#/main

腾讯乐享  https://lexiangla.com/
承运商    http://t.yunjiglobal.com/carrieradminweb/login
