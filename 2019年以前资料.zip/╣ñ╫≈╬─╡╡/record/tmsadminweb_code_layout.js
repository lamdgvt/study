/**
 *  tmsadminweb 代码初次记录大体结构
 *
 *      home.vue 文件 :
 *
 *      if (SELECTED_NAV_STORAGE) 用于记录用户最后一次显示页签内容, 如F5刷新页面,可及时恢复刷新前 显示页签.
 *      else 跳转回首页
 *
 *      获取用户信息 await api("/loginUserInfo", "get")
 *      code === 0 请求成功
 *
 *      ( 头部菜单, 左侧导航栏, 右侧内容栏 )
 *      头部菜单 和 左侧导航栏 数据, 取自 sessionStorage 或后台.
 *      await api("/menuAll", "get").
 *      code === 0 请求成功, 否则 弹出提示框.
 *      以 MENULIST_STORAGES 为 key 存入 sessionStorage, 防止重复请求.
 *
 *      navFlip 头部菜单跳转
 *      
 *      selectNav 左侧导航跳转页签方法
 *      vue-router    this.$router.push()
 *
 *
 *
 *
 *
 *
 */



/**
 *  测试账号 sztest 123456
 *
 */
